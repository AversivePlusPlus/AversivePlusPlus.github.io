#if (__cplusplus < 201103L)

#error "\
This library need C++11, which is not supported by this version of Arduino. \
Please, enable C++11 on this version, or update it. \
"

#endif
